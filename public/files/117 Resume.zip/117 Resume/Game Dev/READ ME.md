##### \# 📂 **Portfolio Access** – Ayobami **\[Klaus]** Oyesiku



Hi there 👋

Thanks for downloading my resume!



To explore my full **Game Development Portfolio** (gameplay videos, project write-ups, screenshots, and demos), please visit my [**Google Drive**](https://drive.google.com/drive/folders/10Et0L9rQhNKPNQf-FEIc67yKkuWvW9Hz?usp=drive_link) folder here:



**🔗 \[Portfolio Google Drive Link]-->** https://drive.google.com/https://drive.google.com/drive/folders/10Et0L9rQhNKPNQf-FEIc67yKkuWvW9Hz?usp=drive\_link



**This portfolio includes:**

\* 🏎️ RACING REALMS  – 	Sim-Arcade Racing  	\[UE5, C++, Blueprints]

\* 🤺 PROJECT XOX    – 	Top-Down Shooter 	\[Unity, C#, FSM AI, Procedural Systems]

\* 🚀 PROJECT ASTRO  – 	Space Shooter 		\[Unity, C#, Procedural Wave Generator, FSM AI]

\* ❌ XO 1999        –	Modern Tic Tac Toe 	\[Unity, C#, Minimax AI] – Shipped 🚀

\* 🎾 PONG 117       – 	Retro Pong Clone 	\[Custom Engine in C++, Win-API] – Shipped 🚀





For ongoing updates and new projects, you can also follow my **\[.DEVLOG]** series on [X (Twitter)](https://x.com/0xKlaus117): \[@0xKlaus117]\*\*



Thanks for taking the time to view my work!

Best regards,

**Ayobami \[Klaus] Oyesiku**

